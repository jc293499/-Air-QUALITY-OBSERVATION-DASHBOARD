"""
generate_sample_data.py - Creates the reproducible SYNTHETIC demonstration
dataset used by the dashboard and the report.

Output:
  data/air_quality_readings.csv   daily PM2.5 + temperature per station
  data/station_metadata.json      station dictionary saved as a file

The values are simulated (fixed random seed) to resemble a Kolkata winter
(Nov-Feb) with high PM2.5. They are NOT real monitoring data.
Run:  python generate_sample_data.py
"""

import csv
import os

import numpy as np
import pandas as pd

from aq_core import DEFAULT_STATIONS, save_station_metadata

SEED = 2026
START, END = "2025-11-01", "2026-02-28"
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")

# station: (baseline PM2.5 multiplier, sampling probability per day)
PROFILE = {
    "KOL01": (0.90, 0.95),
    "KOL02": (1.00, 0.90),
    "KOL03": (1.10, 0.85),
    "KOL04": (0.95, 0.60),
    "KOL05": (1.25, 0.40),   # sparse station
    "KOL06": (1.05, 0.20),   # very sparse low-cost sensor
}

# Injected unusual but physically valid events: (station, date, pm25)
SPIKES = [
    ("KOL02", "2025-11-13", 420.0),   # festival/fireworks-type spike
    ("KOL03", "2025-12-31", 390.0),   # New-Year-eve spike
    ("KOL01", "2026-01-20", 6.0),     # suspiciously low (possible sensor fault)
    ("KOL04", "2026-02-10", 330.0),   # local burning event
]

# Deliberately invalid rows to exercise validation
BAD_ROWS = [
    {"station_id": "KOL01", "date": "2025-11-05", "pm25": "-12", "temperature": "24.0"},
    {"station_id": "KOL02", "date": "2025-12-02", "pm25": "", "temperature": "21.5"},
    {"station_id": "KOL09", "date": "2025-12-10", "pm25": "95", "temperature": "20.0"},
    {"station_id": "KOL03", "date": "2026-13-01", "pm25": "88", "temperature": "19.0"},
    {"station_id": "KOL04", "date": "2026-01-15", "pm25": "1500", "temperature": "18.0"},
    {"station_id": "KOL01", "date": "2026-01-22", "pm25": "110", "temperature": "75"},
]


def build():
    rng = np.random.default_rng(SEED)
    dates = pd.date_range(START, END, freq="D")
    n = len(dates)
    t = np.arange(n)
    # Winter peak around late December / early January
    seasonal = 55 + 60 * np.exp(-((t - 60) / 35.0) ** 2)
    weekly = 6 * np.sin(2 * np.pi * t / 7)
    temp_base = 27 - 9 * np.exp(-((t - 70) / 40.0) ** 2)
    shared = rng.normal(0, 12, n)  # common weather-driven variation

    rows = []
    for sid, (mult, p_sample) in PROFILE.items():
        local = rng.normal(0, 10, n)
        pm = np.clip(mult * (seasonal + weekly) + shared + local, 8, None)
        temp = temp_base + rng.normal(0, 1.2, n)
        keep = rng.random(n) < p_sample
        for i in np.flatnonzero(keep):
            rows.append({"station_id": sid,
                         "date": dates[i].strftime("%Y-%m-%d"),
                         "pm25": round(float(pm[i]), 1),
                         "temperature": round(float(temp[i]), 1)})

    df = pd.DataFrame(rows)
    for sid, d, val in SPIKES:
        mask = (df.station_id == sid) & (df.date == d)
        if mask.any():
            df.loc[mask, "pm25"] = val
        else:
            df.loc[len(df)] = [sid, d, val, 20.0]
    # one duplicate row (same station/date) to test duplicate rejection
    dup = df.iloc[10].to_dict()
    df = pd.concat([df, pd.DataFrame([dup]), pd.DataFrame(BAD_ROWS)], ignore_index=True)
    df = df.sample(frac=1.0, random_state=SEED).reset_index(drop=True)  # unsorted like a real export
    return df


def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    df = build()
    path = os.path.join(DATA_DIR, "air_quality_readings.csv")
    df.to_csv(path, index=False, quoting=csv.QUOTE_MINIMAL)
    save_station_metadata(DEFAULT_STATIONS, os.path.join(DATA_DIR, "station_metadata.json"))
    print(f"Wrote {len(df)} rows to {path}")


if __name__ == "__main__":
    main()
