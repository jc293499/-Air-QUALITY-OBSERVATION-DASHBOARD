"""Unit tests. Run from the project folder:  python -m unittest discover tests -v"""

import os
import sys
import tempfile
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import aq_core as aq  # noqa: E402

ST = aq.DEFAULT_STATIONS


class TestValidation(unittest.TestCase):
    def test_valid_values(self):
        self.assertTrue(aq.is_valid_value(55, "pm25"))
        self.assertTrue(aq.is_valid_value("0", "pm25"))
        for bad in (-1, 1001, "", "abc", None, float("nan")):
            self.assertFalse(aq.is_valid_value(bad, "pm25"))
        self.assertFalse(aq.is_valid_value(75, "temperature"))

    def test_categories(self):
        self.assertEqual(aq.pm25_category(30), "Good")
        self.assertEqual(aq.pm25_category(30.1), "Satisfactory")
        self.assertEqual(aq.pm25_category(95), "Poor")
        self.assertEqual(aq.pm25_category(400), "Severe")
        with self.assertRaises(ValueError):
            aq.pm25_category(-5)

    def test_station_reading(self):
        r = aq.StationReading("kol01", "2026-01-05", "82.5", "", ST)
        self.assertEqual(r.station_id, "KOL01")
        self.assertIsNone(r.temperature)
        self.assertTrue(r.exceeds_limit)
        self.assertEqual(aq.StationReading.from_dict(r.to_dict(), ST).pm25, 82.5)
        for args in (("KOL99", "2026-01-05", 50), ("KOL01", "05/01/2026", 50),
                     ("KOL01", "2026-01-05", -3), ("", "2026-01-05", 50)):
            with self.assertRaises(ValueError):
                aq.StationReading(*args, stations=ST)

    def test_duplicates_rejected(self):
        rows = [{"station_id": "KOL01", "date": "2026-01-01", "pm25": "50", "temperature": "20"}] * 2
        ok, bad = aq.validate_rows(rows, ST)
        self.assertEqual((len(ok), len(bad)), (1, 1))

    def test_missing_column(self):
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False) as fh:
            fh.write("station_id,date,pm25\nKOL01,2026-01-01,40\n")
        try:
            with self.assertRaises(ValueError):
                aq.load_csv(fh.name, ST)
        finally:
            os.remove(fh.name)


class TestStatistics(unittest.TestCase):
    def test_modified_z(self):
        z = aq.modified_zscores([10, 11, 12, 11, 10, 100])
        self.assertTrue(abs(z[-1]) > 3.5)
        self.assertTrue(np.all(np.abs(z[:-1]) <= 3.5))

    def test_zero_mad(self):
        z = aq.modified_zscores([5, 5, 5, 5, 9])
        self.assertTrue(np.isinf(z[-1]))
        self.assertEqual(z[0], 0)

    def test_flag_spike_in_trend(self):
        dates = pd.date_range("2026-01-01", periods=60)
        vals = np.linspace(40, 160, 60) + np.tile([0, 2, -2, 1, -1], 12)
        vals[30] = 400
        df = pd.DataFrame({"station_id": "KOL01", "date": dates, "pm25": vals})
        out = aq.flag_anomalies(df)
        self.assertEqual(out.index[out["anomaly"]].tolist(), [30])

    def test_coverage(self):
        df = pd.DataFrame({"station_id": "KOL01",
                           "date": pd.to_datetime(["2026-01-01", "2026-01-02", "2026-01-10"])})
        cov = aq.coverage_table(df)
        self.assertEqual(cov.loc[0, "readings"], 3)
        self.assertEqual(cov.loc[0, "longest_gap_days"], 7)
        self.assertAlmostEqual(cov.loc[0, "coverage_pct"], 30.0)

    def test_summary_stats(self):
        s = aq.summary_stats([1, 2, 3, np.nan])
        self.assertEqual(s["n"], 3)
        self.assertAlmostEqual(s["mean"], 2.0)
        self.assertEqual(aq.summary_stats([])["n"], 0)


class TestSampleFile(unittest.TestCase):
    def test_sample_csv_loads(self):
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ok, bad = aq.load_csv(os.path.join(here, "data", "air_quality_readings.csv"), ST)
        self.assertGreater(len(ok), 400)
        self.assertEqual(len(bad), 7)


if __name__ == "__main__":
    unittest.main()
