# Air-Quality Observation Dashboard

Python Programming Laboratory project (B.Tech, ECE, Section B, IEM Kolkata, session 2026-2027).

The project analyses local **PM2.5** (fine-particle air pollution) and **temperature** readings from a CSV file. It checks every reading and compares PM2.5 with the Indian NAAQS (60 µg/m³) and WHO (15 µg/m³) 24-hour levels. It keeps station details in a dictionary and a JSON file and stores each reading in a `StationReading` class. NumPy computes averages and finds unusual readings, and Pandas groups the data by station, date and month. The results appear as trend charts and histograms in a Tkinter dashboard.

📄 **Project report:** [`report/Air_Quality_Observation_Dashboard_Project_Report.pdf`](report/Air_Quality_Observation_Dashboard_Project_Report.pdf)

## Team

| Name | Roll No. | Enrollment No. |
|---|---|---|
| Jishu Chatterjee | 224 | 12025052003242 |
| Aritra Rakshit | 223 | 12025052003240 |
| Sudipta Das | 245 | 12025052003263 |
| Anuj Kumar Jha | 226 | 12025052003244 |

## Folder structure

```
Air-Quality-Observation-Dashboard/
├── air_quality_dashboard.py   # MAIN program: Tkinter dashboard (run this)
├── aq_core.py                 # StationReading class, validation, NumPy/Pandas analysis
├── run_analysis.py            # command-line analysis, saves charts + tables to outputs/
├── generate_sample_data.py    # creates the synthetic demo dataset
├── requirements.txt
├── data/
│   ├── air_quality_readings.csv   # demo readings (synthetic, includes invalid rows on purpose)
│   └── station_metadata.json      # station dictionary saved as a file
├── outputs/
│   ├── figures/                   # trend, histogram, station and coverage charts (PNG)
│   └── *.csv / *.json             # station summary, anomalies, coverage, monthly means
├── tests/
│   └── test_aq_core.py            # 11 unit tests
└── report/
    ├── Air_Quality_Observation_Dashboard_Project_Report.pdf
    ├── build_report.py            # rebuilds the PDF from outputs/
    ├── iem_logo.png
    └── fonts/                     # Liberation Sans fonts used by the report
```

## How to run

```bash
pip install -r requirements.txt
python air_quality_dashboard.py              # GUI (or open in IDLE and press F5)
python run_analysis.py                       # PM2.5 analysis, regenerates outputs/
python run_analysis.py --variable temperature
python -m unittest discover tests -v         # run tests
python report/build_report.py                # rebuild the PDF report
```

Tkinter comes with Python on Windows and macOS. On Linux, install it with `sudo apt install python3-tk`.

## CSV format

Required headers: `station_id, date, pm25, temperature` (date as `YYYY-MM-DD`; temperature may be blank).

## Anomaly rule (summary)

For each station, the rule subtracts a 15-day rolling median from every reading. A reading is flagged when the **modified z-score** of that difference, `M = 0.6745 (r − median) / MAD`, satisfies `|M| > 3.5`. The rule is robust to skewed data and to the spikes it is looking for. It does not flag normal winter peaks, and it can also catch readings that are too low. The report (Sections 7–8) explains the limits of sparse sampling and why this rule was chosen.

> **Note:** the demo dataset is **synthetic**, not official monitoring data, so the numbers show how the program behaves. They are not findings about Kolkata's air.
