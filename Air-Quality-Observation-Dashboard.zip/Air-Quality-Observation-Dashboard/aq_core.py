"""
aq_core.py - Core logic for the Air-Quality Observation Dashboard.

Contains:
  * Validation constants and threshold helpers (PM2.5 / temperature)
  * Station metadata handling (dictionary <-> JSON file)
  * StationReading class (one validated observation)
  * CSV loading with row-level validation
  * NumPy statistics and the modified z-score (MAD) anomaly rule
  * Pandas station / date grouping and sampling-coverage analysis

The module has no GUI dependency, so it can be imported by the Tkinter
dashboard, by the figure/report script and by the unit tests.
"""

import csv
import json
import math
from datetime import date, datetime

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# 1. Validation limits and thresholds
# --------------------------------------------------------------------------
VARIABLES = {
    # name: (unit, physical minimum, physical maximum)
    "pm25": ("µg/m³", 0.0, 1000.0),
    "temperature": ("°C", -50.0, 60.0),
}

# India National Ambient Air Quality Standard (NAAQS) and WHO 2021 guideline
# for 24-hour mean PM2.5 (µg/m³).
NAAQS_PM25_24H = 60.0
WHO_PM25_24H = 15.0

# Indian AQI sub-index bands for 24-hour PM2.5 (upper bound, label).
PM25_CATEGORIES = [
    (30.0, "Good"),
    (60.0, "Satisfactory"),
    (90.0, "Moderate"),
    (120.0, "Poor"),
    (250.0, "Very Poor"),
    (math.inf, "Severe"),
]

# Modified z-score anomaly rule (Iglewicz & Hoaglin, 1993).
MZ_CONSTANT = 0.6745
DEFAULT_MZ_THRESHOLD = 3.5

REQUIRED_COLUMNS = ("station_id", "date", "pm25", "temperature")
DATE_FORMAT = "%Y-%m-%d"


def is_valid_value(value, variable="pm25"):
    """Return True if value is a finite number inside the physical range."""
    if variable not in VARIABLES:
        raise ValueError(f"Unknown variable: {variable}")
    try:
        v = float(value)
    except (TypeError, ValueError):
        return False
    _, lo, hi = VARIABLES[variable]
    return math.isfinite(v) and lo <= v <= hi


def pm25_category(value):
    """Map a 24-hour PM2.5 concentration to its Indian AQI category."""
    if not is_valid_value(value, "pm25"):
        raise ValueError(f"Invalid PM2.5 value: {value}")
    v = float(value)
    for upper, label in PM25_CATEGORIES:
        if v <= upper:
            return label
    return "Severe"  # pragma: no cover (unreachable, inf upper bound)


def exceeds_naaqs(value):
    """True if a 24-hour PM2.5 value is above the Indian NAAQS limit."""
    return float(value) > NAAQS_PM25_24H


# --------------------------------------------------------------------------
# 2. Station metadata (dictionary + JSON file)
# --------------------------------------------------------------------------
DEFAULT_STATIONS = {
    "KOL01": {"name": "Victoria Memorial", "area": "Central", "type": "Urban background",
              "lat": 22.5448, "lon": 88.3426},
    "KOL02": {"name": "Jadavpur", "area": "South", "type": "Residential",
              "lat": 22.4986, "lon": 88.3714},
    "KOL03": {"name": "Ballygunge", "area": "South", "type": "Residential/Traffic",
              "lat": 22.5280, "lon": 88.3659},
    "KOL04": {"name": "Bidhannagar", "area": "East", "type": "Commercial",
              "lat": 22.5867, "lon": 88.4171},
    "KOL05": {"name": "Rabindra Bharati", "area": "North", "type": "Traffic",
              "lat": 22.6273, "lon": 88.3807},
    "KOL06": {"name": "Fort William", "area": "Central", "type": "Low-cost sensor",
              "lat": 22.5560, "lon": 88.3420},
}


def save_station_metadata(stations, path):
    """Write the station dictionary to a JSON file."""
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(stations, fh, indent=2, ensure_ascii=False)


def load_station_metadata(path):
    """Read station metadata from JSON; fall back to defaults if missing."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return dict(DEFAULT_STATIONS)
    if not isinstance(data, dict) or not data:
        return dict(DEFAULT_STATIONS)
    return data


# --------------------------------------------------------------------------
# 3. StationReading class
# --------------------------------------------------------------------------
class StationReading:
    """One validated daily observation from a monitoring station."""

    __slots__ = ("station_id", "date", "pm25", "temperature")

    def __init__(self, station_id, obs_date, pm25, temperature=None, stations=None):
        station_id = str(station_id or "").strip().upper()
        if not station_id:
            raise ValueError("station_id is empty")
        if stations is not None and station_id not in stations:
            raise ValueError(f"unknown station '{station_id}'")

        if isinstance(obs_date, datetime):
            obs_date = obs_date.date()
        if not isinstance(obs_date, date):
            try:
                obs_date = datetime.strptime(str(obs_date).strip(), DATE_FORMAT).date()
            except ValueError:
                raise ValueError(f"bad date '{obs_date}' (expected YYYY-MM-DD)") from None

        if not is_valid_value(pm25, "pm25"):
            raise ValueError(f"PM2.5 '{pm25}' not a number in 0-1000")

        if temperature is None or str(temperature).strip() == "":
            temp = None  # temperature is optional
        elif is_valid_value(temperature, "temperature"):
            temp = float(temperature)
        else:
            raise ValueError(f"temperature '{temperature}' not a number in -50-60")

        self.station_id = station_id
        self.date = obs_date
        self.pm25 = float(pm25)
        self.temperature = temp

    @classmethod
    def from_dict(cls, row, stations=None):
        return cls(row.get("station_id"), row.get("date"), row.get("pm25"),
                   row.get("temperature"), stations)

    def to_dict(self):
        return {
            "station_id": self.station_id,
            "date": self.date.strftime(DATE_FORMAT),
            "pm25": self.pm25,
            "temperature": self.temperature,
        }

    @property
    def category(self):
        return pm25_category(self.pm25)

    @property
    def exceeds_limit(self):
        return exceeds_naaqs(self.pm25)

    def __repr__(self):
        return (f"StationReading({self.station_id}, {self.date}, "
                f"pm25={self.pm25}, temp={self.temperature})")


# --------------------------------------------------------------------------
# 4. CSV loading and validation
# --------------------------------------------------------------------------
def validate_rows(rows, stations=None):
    """Validate an iterable of dict rows.

    Returns (readings, rejected) where rejected is a list of
    (line_number, reason) tuples. Duplicate (station, date) pairs are
    rejected after the first occurrence.
    """
    readings, rejected, seen = [], [], set()
    for line_no, row in enumerate(rows, start=2):  # line 1 is the header
        try:
            r = StationReading.from_dict(row, stations)
        except ValueError as exc:
            rejected.append((line_no, str(exc)))
            continue
        key = (r.station_id, r.date)
        if key in seen:
            rejected.append((line_no, f"duplicate {r.station_id} on {r.date}"))
            continue
        seen.add(key)
        readings.append(r)
    return readings, rejected


def load_csv(path, stations=None):
    """Read and validate a readings CSV. Raises ValueError on missing columns."""
    with open(path, "r", newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        header = [h.strip() for h in (reader.fieldnames or [])]
        missing = [c for c in REQUIRED_COLUMNS if c not in header]
        if missing:
            raise ValueError("CSV is missing column(s): " + ", ".join(missing))
        reader.fieldnames = header
        return validate_rows(list(reader), stations)


def readings_to_dataframe(readings, stations=None):
    """Convert StationReading objects to a tidy Pandas DataFrame."""
    df = pd.DataFrame([r.to_dict() for r in readings],
                      columns=["station_id", "date", "pm25", "temperature"])
    df["date"] = pd.to_datetime(df["date"])
    df["temperature"] = pd.to_numeric(df["temperature"], errors="coerce")
    if stations:
        df["station_name"] = df["station_id"].map(
            lambda s: stations.get(s, {}).get("name", s))
    else:
        df["station_name"] = df["station_id"]
    df["category"] = df["pm25"].apply(pm25_category)
    df["exceeds_naaqs"] = df["pm25"] > NAAQS_PM25_24H
    return df.sort_values(["station_id", "date"]).reset_index(drop=True)


# --------------------------------------------------------------------------
# 5. NumPy statistics and anomaly rule
# --------------------------------------------------------------------------
def summary_stats(values):
    """Return descriptive statistics of a 1-D array using NumPy."""
    a = np.asarray(values, dtype=float)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return {"n": 0, "mean": np.nan, "median": np.nan, "std": np.nan,
                "min": np.nan, "max": np.nan, "p95": np.nan}
    return {
        "n": int(a.size),
        "mean": float(np.mean(a)),
        "median": float(np.median(a)),
        "std": float(np.std(a, ddof=1)) if a.size > 1 else 0.0,
        "min": float(np.min(a)),
        "max": float(np.max(a)),
        "p95": float(np.percentile(a, 95)),
    }


def modified_zscores(values):
    """Modified z-score M = 0.6745 (x - median) / MAD.

    NaN values stay NaN. If MAD is zero (more than half the values are
    identical) every score is 0 except values that differ from the median,
    which get +/- inf so they are always flagged.
    """
    a = np.asarray(values, dtype=float)
    out = np.full(a.shape, np.nan)
    ok = np.isfinite(a)
    if not ok.any():
        return out
    med = np.median(a[ok])
    mad = np.median(np.abs(a[ok] - med))
    if mad == 0:
        diff = a[ok] - med
        out[ok] = np.where(diff == 0, 0.0, np.sign(diff) * np.inf)
    else:
        out[ok] = MZ_CONSTANT * (a[ok] - med) / mad
    return out


def iqr_flags(values, k=1.5):
    """Boolean mask of values outside [Q1 - k*IQR, Q3 + k*IQR] (comparison rule)."""
    a = np.asarray(values, dtype=float)
    ok = np.isfinite(a)
    mask = np.zeros(a.shape, dtype=bool)
    if ok.sum() < 4:
        return mask
    q1, q3 = np.percentile(a[ok], [25, 75])
    iqr = q3 - q1
    mask[ok] = (a[ok] < q1 - k * iqr) | (a[ok] > q3 + k * iqr)
    return mask


def rolling_baseline(dates, values, window_days=15, min_periods=5):
    """Centred rolling median over a time window (handles irregular sampling).

    Where fewer than min_periods readings fall in the window (sparse
    station), a three-times-wider window is used instead, so the baseline is
    not built from only one or two neighbouring points.
    """
    s = pd.Series(np.asarray(values, dtype=float), index=pd.DatetimeIndex(dates))
    order = np.argsort(s.index.values, kind="stable")
    s_sorted = s.iloc[order]
    base = s_sorted.rolling(f"{window_days}D", center=True,
                                min_periods=min_periods).median()
    wide = s_sorted.rolling(f"{3 * window_days}D", center=True, min_periods=1).median()
    base = base.fillna(wide)
    out = np.empty(len(s))
    out[order] = base.to_numpy()
    return out


def flag_anomalies(df, variable="pm25", threshold=DEFAULT_MZ_THRESHOLD,
                   min_points=5, window_days=15):
    """Add 'baseline', 'mz' and 'anomaly' columns, separately for each station.

    Rule: residual = value - centred 15-day rolling median of that station;
    a reading is anomalous if |modified z-score of the residual| > threshold.
    Removing the local baseline stops normal seasonal highs being flagged and
    lets unusually LOW readings be caught too. Stations with fewer than
    min_points readings are not scored (median/MAD would be unreliable).
    """
    df = df.copy()
    df["baseline"] = np.nan
    df["mz"] = np.nan
    df["anomaly"] = False
    for sid, idx in df.groupby("station_id").groups.items():
        vals = df.loc[idx, variable].to_numpy(dtype=float)
        if np.isfinite(vals).sum() < min_points:
            continue
        base = rolling_baseline(df.loc[idx, "date"], vals, window_days)
        df.loc[idx, "baseline"] = base
        z = modified_zscores(vals - base)
        df.loc[idx, "mz"] = z
        df.loc[idx, "anomaly"] = np.abs(np.nan_to_num(z, nan=0.0)) > threshold
    return df


# --------------------------------------------------------------------------
# 6. Pandas grouping and sampling coverage
# --------------------------------------------------------------------------
def station_summary(df, variable="pm25"):
    """Per-station summary table."""
    g = df.groupby(["station_id", "station_name"])[variable]
    out = g.agg(readings="count", mean="mean", median="median",
                std="std", max="max").reset_index()
    if variable == "pm25":
        exc = df.groupby("station_id")["exceeds_naaqs"].sum()
        out["days_above_NAAQS"] = out["station_id"].map(exc).astype(int)
    if "anomaly" in df.columns:
        an = df.groupby("station_id")["anomaly"].sum()
        out["anomalies"] = out["station_id"].map(an).astype(int)
    return out.round(2)


def daily_network_mean(df, variable="pm25"):
    """Network-wide daily mean and number of reporting stations per date."""
    return (df.groupby("date")[variable]
              .agg(network_mean="mean", stations_reporting="count")
              .reset_index())


def monthly_summary(df, variable="pm25"):
    """Mean per station per calendar month (pivot table)."""
    m = df.assign(month=df["date"].dt.to_period("M").astype(str))
    return m.pivot_table(index="station_id", columns="month",
                         values=variable, aggfunc="mean").round(1)


def coverage_table(df, start=None, end=None):
    """Sampling coverage per station: readings / calendar days and longest gap."""
    if df.empty:
        return pd.DataFrame(columns=["station_id", "readings", "expected_days",
                                     "coverage_pct", "longest_gap_days"])
    start = pd.Timestamp(start) if start is not None else df["date"].min()
    end = pd.Timestamp(end) if end is not None else df["date"].max()
    expected = (end - start).days + 1
    rows = []
    for sid, grp in df.groupby("station_id"):
        dates = np.sort(grp["date"].to_numpy(dtype="datetime64[D]"))
        bounds = np.concatenate(([np.datetime64(start.date()) - 1], dates,
                                 [np.datetime64(end.date()) + 1]))
        gaps = np.diff(bounds).astype(int) - 1
        rows.append({
            "station_id": sid,
            "readings": int(len(dates)),
            "expected_days": int(expected),
            "coverage_pct": round(100.0 * len(dates) / expected, 1),
            "longest_gap_days": int(gaps.max()) if gaps.size else expected,
        })
    return pd.DataFrame(rows)


def sparse_sampling_experiment(series, fractions=(1.0, 0.5, 0.25, 0.1),
                               trials=500, seed=7):
    """Estimate how the mean of a series varies when only a fraction is sampled.

    Returns a DataFrame with the fraction, number of points used, the mean of
    the sub-sample means and the 5th-95th percentile spread of those means.
    """
    a = np.asarray(series, dtype=float)
    a = a[np.isfinite(a)]
    rng = np.random.default_rng(seed)
    rows = []
    for f in fractions:
        n = max(1, int(round(f * a.size)))
        means = np.array([rng.choice(a, size=n, replace=False).mean()
                          for _ in range(trials)])
        lo, hi = np.percentile(means, [5, 95])
        rows.append({"fraction": f, "points": n, "mean_of_means": round(means.mean(), 2),
                     "p05": round(lo, 2), "p95": round(hi, 2),
                     "spread": round(hi - lo, 2)})
    return pd.DataFrame(rows)
