"""
build_report.py - Rebuilds the project report PDF from the latest results.

Run from the project folder AFTER run_analysis.py:
    python run_analysis.py
    python report/build_report.py
Requires: reportlab (pip install reportlab)
"""

import json
import os

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, ListFlowable, ListItem, PageBreak,
                                Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
FIG = os.path.join(OUT, "figures")
PDF = os.path.join(ROOT, "report", "Air_Quality_Observation_Dashboard_Project_Report.pdf")
LOGO = os.path.join(ROOT, "report", "iem_logo.png")

TITLE = "AIR-QUALITY OBSERVATION DASHBOARD"
DEPT = "Department of Electronics and Communication Engineering"
MEMBERS = [
    ("Jishu Chatterjee", "224", "12025052003242"),
    ("Aritra Rakshit", "223", "12025052003240"),
    ("Sudipta Das", "245", "12025052003263"),
    ("Anuj Kumar Jha", "226", "12025052003244"),
]

from reportlab.lib.fonts import addMapping
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Unicode TTF fonts so that µ, ³, ° and ± print correctly
FONT_DIR = os.path.join(ROOT, "report", "fonts")
for name, file in (("Sans", "LiberationSans-Regular.ttf"), ("Sans-Bold", "LiberationSans-Bold.ttf"),
                   ("Sans-Italic", "LiberationSans-Italic.ttf")):
    pdfmetrics.registerFont(TTFont(name, os.path.join(FONT_DIR, file)))
addMapping("Sans", 0, 0, "Sans")
addMapping("Sans", 1, 0, "Sans-Bold")
addMapping("Sans", 0, 1, "Sans-Italic")
addMapping("Sans", 1, 1, "Sans-Bold")

W, H = A4
ss = getSampleStyleSheet()
BODY = ParagraphStyle("b", parent=ss["Normal"], fontName="Sans", fontSize=10.5,
                      leading=14.5, alignment=TA_JUSTIFY, spaceAfter=6)
H1 = ParagraphStyle("h1", parent=BODY, fontName="Sans-Bold", fontSize=14,
                    leading=18, spaceBefore=8, spaceAfter=6, alignment=0)
H2 = ParagraphStyle("h2", parent=H1, fontSize=11.5, leading=15, spaceBefore=6, spaceAfter=4)
CAP = ParagraphStyle("cap", parent=BODY, fontSize=9, alignment=TA_CENTER,
                     fontName="Sans-Italic")
CELL = ParagraphStyle("cell", parent=BODY, fontSize=9, leading=11.5, alignment=0, spaceAfter=0)
COVER = ParagraphStyle("cov", parent=BODY, fontSize=11.5, leading=17, alignment=0)


def P(t, s=BODY):
    return Paragraph(t, s)


def bullets(items):
    return ListFlowable([ListItem(P(i), leftIndent=12) for i in items],
                        bulletType="bullet", start="•", leftIndent=14)


def table(rows, widths, header=True):
    data = [[P(str(c), CELL) for c in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
             ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfe7f2")),
                  ("FONTNAME", (0, 0), (-1, 0), "Sans-Bold")]
    t.setStyle(TableStyle(style))
    return t


def figure(name, caption, width=16.5 * cm):
    from PIL import Image as PImg
    path = os.path.join(FIG, name)
    w, h = PImg.open(path).size
    return KeepTogether([Image(path, width=width, height=width * h / w), P(caption, CAP)])


def cover(c, doc):
    c.saveState()
    c.setLineWidth(1.5)
    c.rect(1.5 * cm, 1.5 * cm, W - 3 * cm, H - 3 * cm)
    c.drawImage(LOGO, W / 2 - 3 * cm, H - 6.3 * cm, width=6 * cm, height=4.4 * cm,
                preserveAspectRatio=True, mask="auto")
    c.setFont("Times-Bold", 20)
    c.drawCentredString(W / 2, H - 7.5 * cm, "INSTITUTE OF ENGINEERING &")
    c.drawCentredString(W / 2, H - 8.4 * cm, "MANAGEMENT, KOLKATA")
    c.restoreState()


def page(c, doc):
    c.saveState()
    c.setFont("Sans-Bold", 8)
    c.drawRightString(W - 2 * cm, H - 1.3 * cm, TITLE)
    c.setLineWidth(0.4)
    c.line(2 * cm, H - 1.45 * cm, W - 2 * cm, H - 1.45 * cm)
    c.setFont("Sans", 8.5)
    c.drawCentredString(W / 2, 1.2 * cm, f"{DEPT} | Page {doc.page}")
    c.restoreState()


def build():
    res = json.load(open(os.path.join(OUT, "results_pm25.json")))
    rest = json.load(open(os.path.join(OUT, "results_temperature.json")))
    summ = pd.read_csv(os.path.join(OUT, "station_summary_pm25.csv"))
    cov = pd.read_csv(os.path.join(OUT, "sampling_coverage.csv"))
    sparse = pd.read_csv(os.path.join(OUT, "sparse_sampling_experiment.csv"))
    anom = pd.read_csv(os.path.join(OUT, "anomalies_pm25.csv"))
    month = pd.read_csv(os.path.join(OUT, "monthly_means_pm25.csv"))
    st = res["stats"]
    s = []

    # ------------------------------------------------------------- cover
    s.append(Spacer(1, 7.6 * cm))
    s.append(P("<b>COURSE TITLE:</b>&nbsp; BACHELOR OF TECHNOLOGY", COVER))
    s.append(P("<b>SUBJECT:</b>&nbsp; PYTHON PROGRAMMING LABORATORY", COVER))
    s.append(P(f"<b>PROJECT TITLE:</b>&nbsp; {TITLE}", COVER))
    s.append(Spacer(1, 4))
    rows = [["<b>No.</b>", "<b>NAME</b>", "<b>ROLL NO.</b>", "<b>ENROLLMENT NO.</b>"]]
    rows += [[str(i), n, r, e] for i, (n, r, e) in enumerate(MEMBERS, 1)]
    s.append(table(rows, [1.2 * cm, 6 * cm, 3 * cm, 5.5 * cm]))
    s.append(Spacer(1, 10))
    s.append(P("<b>SECTION:</b>&nbsp; B", COVER))
    s.append(P("<b>SUBMITTED TO:</b>&nbsp; PYTHON LABORATORY", COVER))
    s.append(P("<b>DEPARTMENT NAME:</b>&nbsp; ELECTRONICS AND COMMUNICATION ENGINEERING", COVER))
    s.append(P("<b>ACADEMIC SESSION:</b>&nbsp; 2026-2027", COVER))
    s.append(P("<b>DATE OF SUBMISSION:</b>&nbsp; 20-11-2026", COVER))
    s.append(PageBreak())

    # ------------------------------------------------------------- abstract
    s.append(P("Abstract", H1))
    s.append(P(
        "This project develops a Python-based desktop dashboard to analyse local measurements of "
        "fine-particle air pollution (PM2.5, µg/m³) and air temperature (°C) recorded at several "
        "monitoring stations and supplied as a CSV file. The program validates every reading against "
        "physical limits, keeps station metadata in a dictionary that is also stored as a JSON file, "
        "represents each observation with a <b>StationReading</b> class, uses NumPy for averages and "
        "anomaly scores, uses Pandas to group readings by station and date, and draws trend charts, "
        "histograms, station box plots and sampling-coverage charts with Matplotlib inside a Tkinter "
        "interface."))
    s.append(P(
        f"The demonstration dataset is <b>synthetically generated</b> for six Kolkata-area stations "
        f"(1 Nov 2025 - 28 Feb 2026); it is not official monitoring data. Of {res['input_rows']} input rows, "
        f"{res['valid']} pass validation and {len(res['rejected'])} are rejected. The mean PM2.5 is "
        f"{st['mean']:.1f} µg/m³ (median {st['median']:.1f}); {res['pct_above_naaqs']}% of readings exceed "
        f"the Indian 24-hour NAAQS of 60 µg/m³. An anomaly rule based on the modified z-score of residuals "
        f"from a 15-day rolling median flags {res['anomalies']} readings, including all four injected "
        f"events, without flagging normal mid-winter peaks. A sub-sampling experiment shows that keeping "
        f"only 10% of days widens the 5th-95th percentile range of a station mean to about "
        f"±{sparse['spread'].iloc[-1] / 2:.0f} µg/m³, quantifying the limits of sparse sampling."))
    s.append(P("Keywords", H2))
    s.append(P("Air quality; PM2.5; temperature; Python; CSV; Tkinter; NumPy; Pandas; Matplotlib; "
               "anomaly detection; modified z-score; sparse sampling."))
    s.append(P("Table of Contents", H1))
    toc = ["Introduction", "Problem Statement and Objectives", "Software and System Requirements",
           "System Design and Methodology", "Implementation of Major Modules", "Results and Discussion",
           "Limits of Sparse Sampling", "Justification of the Anomaly Rule", "Testing and Validation",
           "Limitations and Future Scope", "Conclusion", "References",
           "Appendix: CSV Format, Repository Structure and Execution"]
    for i, t in enumerate(toc, 1):
        s.append(P(f"{i}. {t}", ParagraphStyle("toc", parent=BODY, spaceAfter=2)))
    s.append(PageBreak())

    # ------------------------------------------------------------- 1-3
    s.append(P("1. Introduction", H1))
    s.append(P(
        "Fine particulate matter with aerodynamic diameter of 2.5 µm or less (PM2.5) penetrates deep "
        "into the lungs and is a major urban health risk, especially in Indian cities during winter, "
        "when low mixing heights and calm winds trap pollutants. Monitoring networks produce daily "
        "readings per station, but raw spreadsheets are hard to inspect: values may be missing, "
        "physically impossible, duplicated, or unusually high or low. A small analytical dashboard "
        "standardises validation and presents trends, distributions and unusual observations in one "
        "place."))
    s.append(P(
        "The developed application is a Python desktop interface. It shows key indicators, a trend "
        "chart with standard limits, a histogram with AQI-category counts, a station comparison, a "
        "sampling-coverage chart, tables of anomalies and rejected rows, and an automatically written "
        "interpretation. Users can work with the included synthetic dataset or import their own CSV."))
    s.append(P("2. Problem Statement and Objectives", H1))
    s.append(P(
        "<b>Problem statement:</b> Analyse local measurements of PM2.5 or temperature from a provided "
        "CSV file. Validate readings and thresholds; maintain station metadata in dictionaries/files; "
        "implement a StationReading class; use NumPy for averages and anomalous values; use Pandas for "
        "station/date groups; draw trends and histograms. Explain the limits of sparse sampling and "
        "justify the selected anomaly rule."))
    s.append(P("The principal objectives are:"))
    s.append(bullets([
        "Validate each row (station, date, PM2.5, temperature) and reject impossible or duplicate values.",
        "Compare readings with the Indian NAAQS (60 µg/m³) and WHO 2021 (15 µg/m³) 24-hour PM2.5 "
        "levels and classify them into Indian AQI categories.",
        "Store station metadata (name, area, type, latitude, longitude) in a dictionary and a JSON file.",
        "Encapsulate observations in a StationReading class with validation and conversion methods.",
        "Compute averages, spread, percentiles and anomaly scores with NumPy.",
        "Group by station, date and month with Pandas; measure sampling coverage and gaps.",
        "Draw trend lines, histograms, box plots and coverage charts; explain the results honestly.",
    ]))
    s.append(P("3. Software and System Requirements", H1))
    s.append(table([
        ["Component", "Purpose"],
        ["Python 3.9 or later", "Core program execution"],
        ["Tkinter / ttk", "Desktop graphical user interface"],
        ["csv, json, datetime, math", "CSV reading, metadata file, date and number validation"],
        ["NumPy", "Arrays, mean/median/percentiles, modified z-scores, IQR comparison"],
        ["Pandas", "DataFrame, group-by station/date/month, rolling median, pivot tables"],
        ["Matplotlib", "Trend lines, histograms, bar charts and box plots"],
        ["unittest", "Automated tests of validation and statistics"],
        ["Python IDLE / terminal", "Run the program (IDLE: Run Module, F5)"],
    ], [5.5 * cm, 11 * cm]))
    s.append(Spacer(1, 4))
    s.append(P("Install third-party packages with: <font face='Courier'>pip install -r requirements.txt"
               "</font>. Tkinter ships with standard Python on Windows and macOS; on Linux install the "
               "<font face='Courier'>python3-tk</font> package."))

    # ------------------------------------------------------------- 4
    s.append(P("4. System Design and Methodology", H1))
    s.append(P("4.1 Input data and schema", H2))
    s.append(P(
        "Each CSV row has four fields: <b>station_id</b> (e.g. KOL01), <b>date</b> (YYYY-MM-DD), "
        "<b>pm25</b> (24-hour mean, µg/m³) and <b>temperature</b> (daily mean, °C; may be blank). "
        "Station details are not repeated in every row; they are looked up from "
        "<font face='Courier'>data/station_metadata.json</font>, which is loaded into a Python dictionary."))
    s.append(table([
        ["ID", "Station", "Area", "Type", "Coverage"],
        *[[r.station_id, r.station_name, a, t, f"{c:.0f}%"] for r, a, t, c in zip(
            summ.itertuples(),
            ["Central", "South", "South", "East", "North", "Central"],
            ["Urban background", "Residential", "Residential/Traffic", "Commercial", "Traffic",
             "Low-cost sensor"],
            cov["coverage_pct"])],
    ], [1.6 * cm, 4.2 * cm, 2.4 * cm, 4.6 * cm, 2.4 * cm]))
    s.append(P("4.2 Validation rules", H2))
    s.append(bullets([
        "station_id must be non-empty and present in the station dictionary.",
        "date must parse as YYYY-MM-DD (e.g. 2026-13-01 is rejected).",
        "pm25 must be numeric and within 0-1000 µg/m³; temperature, if present, within -50 to 60 °C.",
        "Only the first reading for a (station, date) pair is kept; later duplicates are rejected.",
        "Every rejected row is reported with its CSV line number and the reason.",
    ]))
    s.append(P("4.3 Analysis workflow", H2))
    s.append(bullets([
        "Read the CSV with csv.DictReader and check the required columns.",
        "Create StationReading objects; collect rejected rows.",
        "Build a Pandas DataFrame, add station names, AQI category and NAAQS exceedance.",
        "For each station compute a 15-day rolling-median baseline and the modified z-score of the "
        "residuals; flag |M| &gt; 3.5 as anomalous.",
        "Group by station, date and month; compute coverage and the longest gap.",
        "Run the sparse-sampling experiment and refresh all charts, tables and text.",
    ]))
    s.append(P("4.4 Statistical measures", H2))
    s.append(P(
        "Mean and median describe the centre, the sample standard deviation (ddof = 1) the spread, "
        "and the 95th percentile the high tail. For anomaly scoring, the residual r = x - "
        "baseline is computed, where baseline is the centred 15-day rolling median of the same "
        "station (a 45-day window is used when fewer than five readings fall in 15 days). The "
        "modified z-score is <b>M = 0.6745 (r - median(r)) / MAD</b>, where MAD = median(|r - "
        "median(r)|). A reading is anomalous when |M| &gt; 3.5 (Iglewicz and Hoaglin). Stations with "
        "fewer than five readings are not scored."))

    # ------------------------------------------------------------- 5
    s.append(P("5. Implementation of Major Modules", H1))
    s.append(table([
        ["File / function", "Functionality"],
        ["aq_core.is_valid_value(), pm25_category(), exceeds_naaqs()", "Range validation, AQI category, NAAQS check"],
        ["DEFAULT_STATIONS, load/save_station_metadata()", "Station dictionary and JSON file"],
        ["StationReading, from_dict(), to_dict()", "Object-oriented, validated observation"],
        ["validate_rows(), load_csv(), readings_to_dataframe()", "CSV import, rejection log, DataFrame"],
        ["summary_stats(), modified_zscores(), iqr_flags()", "NumPy statistics and outlier scores"],
        ["rolling_baseline(), flag_anomalies()", "Per-station de-trended anomaly rule"],
        ["station_summary(), daily_network_mean(), monthly_summary()", "Pandas station/date/month groups"],
        ["coverage_table(), sparse_sampling_experiment()", "Sampling coverage, gaps, sub-sampling"],
        ["air_quality_dashboard.py: Dashboard", "Tkinter GUI, filters, KPI cards, charts, tables, export"],
        ["run_analysis.py", "Command-line analysis; saves figures and CSV results"],
        ["generate_sample_data.py", "Reproducible synthetic dataset (seed 2026)"],
        ["tests/test_aq_core.py", "11 unit tests"],
    ], [8 * cm, 8.5 * cm]))
    s.append(P("5.1 Interface layout", H2))
    s.append(P(
        "The toolbar contains Open CSV, Export filtered CSV, a variable selector (pm25 / temperature), "
        "a station selector and an anomaly-threshold spin box (2.0-6.0). Six KPI cards show the number "
        "of readings, mean, median, maximum, percentage above NAAQS and anomaly count. Six tabs show "
        "Trends, Histogram, Stations, Coverage, Tables (station summary, anomalies, rejected rows) and "
        "Written analysis."))
    s.append(P("5.2 PM2.5 thresholds and categories", H2))
    s.append(table([
        ["24-h PM2.5 (µg/m³)", "0-30", "31-60", "61-90", "91-120", "121-250", "&gt;250"],
        ["Indian AQI category", "Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe"],
    ], [3.6 * cm] + [2.15 * cm] * 6))
    s.append(Spacer(1, 4))
    s.append(P("Reference lines: India NAAQS 24-hour limit 60 µg/m³ and WHO 2021 24-hour guideline 15 µg/m³."))

    # ------------------------------------------------------------- 6
    s.append(P("6. Results and Discussion", H1))
    s.append(P("6.1 Validation and descriptive findings", H2))
    s.append(P("The results below come from the fixed-seed synthetic dataset; they change if another "
               "CSV, station filter or threshold is used."))
    s.append(table([
        ["Indicator", "Observed value"],
        ["Input rows / valid / rejected", f"{res['input_rows']} / {res['valid']} / {len(res['rejected'])}"],
        ["Mean / median PM2.5", f"{st['mean']:.2f} / {st['median']:.2f} µg/m³"],
        ["Standard deviation / 95th percentile", f"{st['std']:.2f} / {st['p95']:.2f} µg/m³"],
        ["Minimum / maximum", f"{st['min']:.1f} / {st['max']:.1f} µg/m³"],
        ["Readings above NAAQS 60", f"{res['days_above_naaqs']} ({res['pct_above_naaqs']}%)"],
        ["Readings above WHO 15", f"{res['pct_above_who']}%"],
        ["Anomalies flagged (|M| &gt; 3.5)", f"{res['anomalies']}"],
        ["Mean temperature", f"{rest['stats']['mean']:.2f} °C (range {rest['stats']['min']}-{rest['stats']['max']} °C)"],
    ], [8 * cm, 8.5 * cm]))
    s.append(Spacer(1, 4))
    s.append(P("Rejected rows (all deliberately inserted to test validation):"))
    s.append(table([["CSV line", "Reason"]] + [[str(a), b] for a, b in res["rejected"]],
                   [3 * cm, 13.5 * cm]))
    s.append(Spacer(1, 6))
    s.append(figure("fig1_pm25_trends.png",
                    "Figure 1. Daily PM2.5 by station with the network 7-day mean, standard limits and "
                    "flagged anomalies."))
    s.append(P(
        f"Figure 1 shows a clear winter build-up: the network monthly mean rises from about 72 µg/m³ in "
        f"November to about 114 µg/m³ in December, then falls to about 68 µg/m³ in February. Almost every "
        f"day lies above the WHO guideline, and {res['pct_above_naaqs']}% of readings exceed the national "
        f"limit."))
    s.append(figure("fig2_pm25_histogram.png",
                    "Figure 2. Histogram of PM2.5 (left) and readings per Indian AQI category (right)."))
    s.append(P(
        "The distribution is right-skewed: the mean is above the median and a few extreme values form "
        "a long upper tail. 'Moderate' and 'Poor' are the most frequent categories. Because of this "
        "skew, median-based statistics are more representative than the mean and standard deviation."))
    s.append(P("6.2 Station-wise summaries (Pandas group-by)", H2))
    s.append(table([["Station", "Name", "Readings", "Mean", "Median", "Max", "&gt; NAAQS", "Anomalies"]] +
                   [[r.station_id, r.station_name, r.readings, f"{r.mean:.1f}", f"{r.median:.1f}",
                     f"{r.max:.1f}", r.days_above_NAAQS, r.anomalies] for r in summ.itertuples()],
                   [1.7 * cm, 3.4 * cm, 1.8 * cm, 1.6 * cm, 1.7 * cm, 1.6 * cm, 1.9 * cm, 2 * cm]))
    s.append(Spacer(1, 4))
    s.append(table([["Station"] + list(month.columns[1:])] +
                   [[r[0]] + [f"{v:.1f}" for v in r[1:]] for r in month.itertuples(index=False)],
                   [3 * cm] + [3.3 * cm] * (len(month.columns) - 1)))
    s.append(P("Table: monthly mean PM2.5 (µg/m³) by station.", CAP))
    s.append(figure("fig3_pm25_by_station.png", "Figure 3. PM2.5 distribution by station.", 13 * cm))
    s.append(P(
        "KOL05 (Rabindra Bharati, traffic site) has the highest mean, but it reported on only 41% of "
        "days, so part of the difference may come from <i>which</i> days were sampled. Such group "
        "differences are descriptive and should not be read as proof that one location is intrinsically "
        "more polluted."))
    s.append(P("6.3 Flagged anomalies", H2))
    s.append(table([["Station", "Date", "PM2.5", "M", "Interpretation"]] +
                   [[r.station_id, r.date, f"{r.pm25:.1f}", f"{r.mz:.2f}",
                     "Injected spike (event)" if r.pm25 > 300 else
                     ("Injected low value (possible sensor fault)" if r.pm25 < 10
                      else "Unusually clean day; check rain/wind")]
                    for r in anom.itertuples()],
                   [2 * cm, 2.6 * cm, 2 * cm, 1.8 * cm, 8.1 * cm]))
    s.append(Spacer(1, 4))
    s.append(P(
        "All four injected events were detected: three high spikes (420, 390 and 330 µg/m³, M &gt; 16) "
        "and one suspiciously low reading (6 µg/m³, M = -6.5). Two further low KOL01 values were "
        "flagged; they are physically possible (e.g. a rain-washout day) and are therefore reported "
        "for checking, not deleted. For temperature, the same rule flagged "
        f"{rest['anomalies']} readings, all at the sparse station KOL05, illustrating that a short "
        "record makes the baseline and MAD less reliable."))

    # ------------------------------------------------------------- 7 sparse
    s.append(P("7. Limits of Sparse Sampling", H1))
    s.append(table([["Station", "Readings", "Expected days", "Coverage %", "Longest gap (days)"]] +
                   [[r.station_id, r.readings, r.expected_days, r.coverage_pct, r.longest_gap_days]
                    for r in cov.itertuples()],
                   [3 * cm, 3 * cm, 3.4 * cm, 3.3 * cm, 3.8 * cm]))
    s.append(Spacer(1, 6))
    s.append(figure("fig4_pm25_sampling_coverage.png",
                    "Figure 4. Coverage per station (left) and spread of the KOL01 mean when only a "
                    "fraction of days is kept, 500 random trials (right)."))
    s.append(table([["Days kept", "Points", "Mean of means", "5th pct", "95th pct", "Spread"]] +
                   [[f"{int(r.fraction * 100)}%", r.points, r.mean_of_means, r.p05, r.p95, r.spread]
                    for r in sparse.itertuples()],
                   [2.6 * cm, 2.2 * cm, 3.2 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm]))
    s.append(Spacer(1, 6))
    s.append(P(
        "The experiment took the best-covered station (KOL01) and repeatedly kept a random fraction of "
        "its days. The average estimate stays unbiased, but its uncertainty grows sharply: with 10% of "
        f"days the 90% range is about {sparse['spread'].iloc[-1]:.0f} µg/m³ wide, versus "
        f"{sparse['spread'].iloc[1]:.0f} µg/m³ with 50%. The main limits of sparse sampling are:"))
    s.append(bullets([
        "<b>Larger uncertainty:</b> the standard error of a mean falls only as 1/sqrt(n), so a station "
        "with 31 readings is much less certain than one with 118.",
        "<b>Missed episodes:</b> short events (a festival night, a fire) are invisible if the sensor "
        "did not report that day; KOL06 has an 18-day gap.",
        "<b>Biased comparisons:</b> if stations report on different days, a station sampled mostly in "
        "December looks dirtier than one sampled in February. Fair comparison should use common days "
        "or monthly means with coverage shown.",
        "<b>Weaker anomaly detection:</b> the rolling baseline and MAD need enough neighbouring points; "
        "with few points, normal noise can be flagged (temperature at KOL05) or real spikes missed. "
        "Hence stations with &lt; 5 readings are not scored and a wider window is used when data are thin.",
        "<b>Compliance statistics:</b> exceedance percentages and averages from &lt; 75% coverage are "
        "commonly treated as indicative only, because regulators require minimum data capture.",
    ]))

    # ------------------------------------------------------------- 8 justification
    s.append(P("8. Justification of the Anomaly Rule", H1))
    s.append(P(
        "Selected rule: <b>per-station modified z-score of residuals from a 15-day rolling median, "
        "threshold |M| &gt; 3.5</b>. It was chosen over simpler alternatives for these reasons:"))
    s.append(bullets([
        "<b>Robust statistics:</b> median and MAD are hardly affected by the very spikes being "
        "searched for, whereas mean and standard deviation are inflated by them (masking).",
        "<b>Skewed data:</b> PM2.5 is right-skewed, so a normal-theory mean ± 3σ rule is not appropriate.",
        "<b>Seasonality:</b> removing the local 15-day baseline means that a normal mid-winter value "
        "is not flagged just because winter is polluted, and a low value in a high-pollution month can "
        "still be detected.",
        "<b>Per station:</b> each site is compared with its own history, so a traffic site is not "
        "flagged simply for being busier than a background site.",
        "<b>Accepted threshold:</b> 3.5 is the value recommended by Iglewicz and Hoaglin; the GUI lets "
        "the user change it to test sensitivity.",
    ]))
    s.append(table([
        ["Rule (PM2.5, same data)", "Flagged", "Comment"],
        ["Per-station IQR on raw values (k = 1.5)", str(res["iqr_flags"]),
         "Catches the spikes but also flags normal peak-winter days (150.2 and 152.8 µg/m³)"],
        ["Modified z on raw values, all stations pooled", "3",
         "Misses the 6 µg/m³ fault because winter variation inflates the MAD"],
        ["Selected rule, |M| &gt; 3.5", str(res["anomalies"]),
         "All 4 injected events + 2 low days for review; no seasonal peaks"],
        ["Selected rule, |M| &gt; 5.0", "4", "Exactly the 4 injected events (stricter)"],
        ["Selected rule, |M| &gt; 3.0", "7", "More sensitive, more false alarms"],
    ], [6 * cm, 1.8 * cm, 8.7 * cm]))
    s.append(Spacer(1, 4))
    s.append(P(
        "An anomaly is a statistically unusual reading, not automatically an error. Flagged values are "
        "shown for review and the analysis is not silently altered; deciding whether to remove them "
        "requires external evidence such as event logs, weather or sensor maintenance records."))

    # ------------------------------------------------------------- 9 testing
    s.append(P("9. Testing and Validation", H1))
    s.append(table([
        ["Test case", "Expected behaviour", "Observed"],
        ["Load sample CSV", "Valid rows accepted, invalid reported", f"{res['valid']} accepted; {len(res['rejected'])} rejected"],
        ["PM2.5 = -12 or 1500", "Reject outside 0-1000", "Rejected"],
        ["Blank PM2.5", "Reject non-numeric", "Rejected"],
        ["Unknown station KOL09", "Reject (not in dictionary)", "Rejected"],
        ["Date 2026-13-01", "Reject invalid date", "Rejected"],
        ["Temperature 75 °C", "Reject outside -50 to 60", "Rejected"],
        ["Duplicate station/date", "Keep first, reject repeat", "Rejected"],
        ["Missing CSV column", "Clear error message", "ValueError shown"],
        ["Spike in rising trend", "Only the spike flagged", "Passed (unit test)"],
        ["MAD = 0", "No division by zero", "Passed (unit test)"],
        ["Station / variable / threshold change", "Charts and KPIs recalculated", "Verified in GUI"],
        ["Export filtered CSV", "Current selection written", "Implemented via to_csv"],
    ], [5 * cm, 6 * cm, 5.5 * cm]))
    s.append(Spacer(1, 4))
    s.append(P("All 11 automated tests pass (<font face='Courier'>python -m unittest discover tests -v</font>). "
               "The GUI was started and exercised (station filter, temperature view, threshold change) "
               "on Python 3.12 with Tkinter; it should also be checked manually on the presentation "
               "computer."))

    # ------------------------------------------------------------- 10-12
    s.append(P("10. Limitations and Future Scope", H1))
    s.append(P(
        "Limitations: (i) the included data are synthetic, so the numbers demonstrate program behaviour "
        "and are not evidence about Kolkata's air; (ii) daily means hide hourly peaks; (iii) low-cost "
        "sensors need calibration and humidity correction that is not modelled; (iv) the analysis is "
        "descriptive, not predictive or causal; (v) the anomaly threshold is a convention and should be "
        "tuned with labelled events."))
    s.append(P(
        "Future scope: import real data from the CPCB / WBPCB portals, hourly data and AQI computation "
        "from several pollutants, a map of stations using the stored latitude/longitude, gap-filling "
        "with uncertainty bands, correlation with weather (temperature, wind, rain), and a web version."))
    s.append(P("11. Conclusion", H1))
    s.append(P(
        "The project delivers a complete workflow for local air-quality observations: CSV validation "
        "with a rejection log, station metadata in a dictionary and JSON file, a StationReading class, "
        "NumPy statistics and a robust anomaly rule, Pandas grouping by station, date and month, and "
        "Matplotlib charts inside a Tkinter dashboard. On the demonstration data, PM2.5 peaks in "
        "December and most readings exceed the national limit; the chosen rule finds every injected "
        "event without flagging normal winter peaks. The coverage analysis shows that results from "
        "sparsely sampled stations must be reported with their coverage and treated with caution."))
    s.append(P("12. References", H1))
    for r in [
        "Python Software Foundation. Python 3 Documentation. https://docs.python.org/3/",
        "NumPy Developers. NumPy Documentation. https://numpy.org/doc/",
        "pandas Development Team. pandas Documentation. https://pandas.pydata.org/docs/",
        "Matplotlib Development Team. Matplotlib Documentation. https://matplotlib.org/stable/",
        "Python Software Foundation. tkinter - Python interface to Tcl/Tk. https://docs.python.org/3/library/tkinter.html",
        "Central Pollution Control Board (2009). National Ambient Air Quality Standards. New Delhi.",
        "Central Pollution Control Board (2014). National Air Quality Index. New Delhi.",
        "World Health Organization (2021). WHO Global Air Quality Guidelines. Geneva.",
        "Iglewicz, B. and Hoaglin, D. (1993). How to Detect and Handle Outliers. ASQC Quality Press.",
    ]:
        s.append(P(r, ParagraphStyle("ref", parent=BODY, spaceAfter=3)))

    # ------------------------------------------------------------- appendix
    s.append(P("13. Appendix: CSV Format, Repository Structure and Execution", H1))
    s.append(KeepTogether([P("Required CSV headers (exact spelling): station_id, date, pm25, temperature."),
                           table([["station_id", "date", "pm25", "temperature"],
                    ["KOL01", "2025-12-20", "150.2", "18.4"],
                    ["KOL02", "2025-11-13", "420.0", "24.9"],
                    ["KOL06", "2026-01-05", "98.6", ""]], [4 * cm] * 4)]))
    s.append(Spacer(1, 6))
    mono = ParagraphStyle("mono", parent=BODY, fontName="Courier", fontSize=8.5, leading=11,
                          alignment=0)
    s.append(P(
        "Air-Quality-Observation-Dashboard/<br/>"
        "&nbsp;&nbsp;air_quality_dashboard.py &nbsp;&nbsp;# main Tkinter dashboard<br/>"
        "&nbsp;&nbsp;aq_core.py &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# StationReading, validation, statistics<br/>"
        "&nbsp;&nbsp;run_analysis.py &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# command-line analysis + figures<br/>"
        "&nbsp;&nbsp;generate_sample_data.py &nbsp;&nbsp;# synthetic dataset<br/>"
        "&nbsp;&nbsp;data/ &nbsp;&nbsp;&nbsp;air_quality_readings.csv, station_metadata.json<br/>"
        "&nbsp;&nbsp;outputs/ figures/*.png and result tables (CSV/JSON)<br/>"
        "&nbsp;&nbsp;tests/ &nbsp;&nbsp;test_aq_core.py<br/>"
        "&nbsp;&nbsp;report/ Air_Quality_Observation_Dashboard_Project_Report.pdf, build_report.py", mono))
    s.append(P("Execution steps:"))
    s.append(bullets([
        "<font face='Courier'>pip install -r requirements.txt</font>",
        "<font face='Courier'>python air_quality_dashboard.py</font> (or open it in IDLE and press F5), "
        "then use Open CSV to load another file.",
        "<font face='Courier'>python run_analysis.py</font> to regenerate charts and tables; add "
        "<font face='Courier'>--variable temperature</font> for temperature.",
        "<font face='Courier'>python -m unittest discover tests -v</font> to run the tests.",
    ]))

    doc = SimpleDocTemplate(PDF, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm, title=TITLE,
                            author="Jishu Chatterjee, Aritra Rakshit, Sudipta Das, Anuj Kumar Jha")
    doc.build(s, onFirstPage=cover, onLaterPages=page)
    print("Report written to", PDF)


if __name__ == "__main__":
    build()
