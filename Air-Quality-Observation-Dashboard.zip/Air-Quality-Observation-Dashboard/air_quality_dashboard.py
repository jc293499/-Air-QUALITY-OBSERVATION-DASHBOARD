"""
air_quality_dashboard.py - Tkinter desktop dashboard (MAIN PROGRAM).

Run:  python air_quality_dashboard.py      (or open in IDLE and press F5)

Features
  * Open any CSV with columns station_id, date, pm25, temperature
  * Choose variable (PM2.5 / temperature), station filter and anomaly threshold
  * KPI cards, trend chart, histogram, station comparison, coverage chart
  * Tables of station summary, anomalies and rejected rows
  * Written analysis and export of the filtered data to CSV
"""

import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np

import aq_core as aq

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CSV = os.path.join(HERE, "data", "air_quality_readings.csv")
META_JSON = os.path.join(HERE, "data", "station_metadata.json")


class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Air-Quality Observation Dashboard")
        self.geometry("1200x780")
        self.minsize(950, 650)
        self.stations = aq.load_station_metadata(META_JSON)
        self.df_all = None
        self.df_view = None
        self.rejected = []
        self.csv_path = None
        self._build()
        if os.path.exists(DEFAULT_CSV):
            self.load(DEFAULT_CSV)

    # ------------------------------------------------------------ layout
    def _build(self):
        bar = ttk.Frame(self, padding=6)
        bar.pack(fill="x")
        ttk.Button(bar, text="Open CSV", command=self.open_csv).pack(side="left")
        ttk.Button(bar, text="Export filtered CSV", command=self.save_csv).pack(side="left", padx=4)

        ttk.Label(bar, text="  Variable:").pack(side="left")
        self.var_choice = tk.StringVar(value="pm25")
        cb = ttk.Combobox(bar, textvariable=self.var_choice, values=list(aq.VARIABLES),
                          width=12, state="readonly")
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.recompute())

        ttk.Label(bar, text="  Station:").pack(side="left")
        self.station_choice = tk.StringVar(value="All")
        self.station_cb = ttk.Combobox(bar, textvariable=self.station_choice,
                                       width=24, state="readonly")
        self.station_cb.pack(side="left")
        self.station_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        ttk.Label(bar, text="  Anomaly |M| >").pack(side="left")
        self.thr = tk.DoubleVar(value=aq.DEFAULT_MZ_THRESHOLD)
        sp = ttk.Spinbox(bar, from_=2.0, to=6.0, increment=0.5, textvariable=self.thr,
                         width=5, command=self.recompute)
        sp.pack(side="left")
        sp.bind("<Return>", lambda e: self.recompute())

        self.status = tk.StringVar(value="No data loaded")
        ttk.Label(self, textvariable=self.status, padding=(8, 0)).pack(fill="x")

        cards = ttk.Frame(self, padding=6)
        cards.pack(fill="x")
        self.kpi = {}
        for key in ("Readings", "Mean", "Median", "Max", "Above NAAQS", "Anomalies"):
            f = ttk.LabelFrame(cards, text=key, padding=6)
            f.pack(side="left", expand=True, fill="x", padx=3)
            v = tk.StringVar(value="-")
            ttk.Label(f, textvariable=v, font=("Segoe UI", 14, "bold")).pack()
            self.kpi[key] = v

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.figs = {}
        for name in ("Trends", "Histogram", "Stations", "Coverage"):
            frame = ttk.Frame(self.nb)
            self.nb.add(frame, text=name)
            fig = Figure(figsize=(9, 4.5), dpi=100)
            canvas = FigureCanvasTkAgg(fig, master=frame)
            canvas.get_tk_widget().pack(fill="both", expand=True)
            self.figs[name] = (fig, canvas)

        tables = ttk.Frame(self.nb)
        self.nb.add(tables, text="Tables")
        self.tree_summary = self._tree(tables, "Station summary")
        self.tree_anom = self._tree(tables, "Anomalies")
        self.tree_rej = self._tree(tables, "Rejected rows")

        frame = ttk.Frame(self.nb)
        self.nb.add(frame, text="Written analysis")
        self.text = tk.Text(frame, wrap="word", font=("Segoe UI", 10), padx=10, pady=10)
        self.text.pack(fill="both", expand=True)

    def _tree(self, parent, title):
        lf = ttk.LabelFrame(parent, text=title, padding=4)
        lf.pack(fill="both", expand=True, padx=4, pady=2)
        tree = ttk.Treeview(lf, show="headings", height=6)
        sb = ttk.Scrollbar(lf, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        return tree

    @staticmethod
    def _fill(tree, columns, rows):
        tree.delete(*tree.get_children())
        tree["columns"] = columns
        for c in columns:
            tree.heading(c, text=c)
            tree.column(c, width=110, anchor="center")
        for r in rows:
            tree.insert("", "end", values=list(r))

    # ------------------------------------------------------------ data
    def open_csv(self):
        path = filedialog.askopenfilename(title="Open readings CSV",
                                          filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if path:
            self.load(path)

    def load(self, path):
        try:
            readings, rejected = aq.load_csv(path, self.stations)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Cannot load file", str(exc))
            return
        if not readings:
            messagebox.showwarning("No valid rows", "The file contains no valid readings.")
            return
        self.csv_path, self.rejected = path, rejected
        self.df_all = aq.readings_to_dataframe(readings, self.stations)
        ids = sorted(self.df_all["station_id"].unique())
        self.station_cb["values"] = ["All"] + [f"{s} - {self.stations.get(s, {}).get('name', s)}"
                                               for s in ids]
        self.station_choice.set("All")
        self.recompute()

    def recompute(self):
        if self.df_all is None:
            return
        try:
            thr = float(self.thr.get())
        except (tk.TclError, ValueError):
            thr = aq.DEFAULT_MZ_THRESHOLD
            self.thr.set(thr)
        var = self.var_choice.get()
        df = self.df_all.dropna(subset=[var])
        self.df_flagged = aq.flag_anomalies(df, var, thr)
        self.refresh()

    def refresh(self):
        if self.df_all is None:
            return
        var = self.var_choice.get()
        sel = self.station_choice.get()
        df = self.df_flagged
        if sel != "All":
            df = df[df["station_id"] == sel.split(" - ")[0]]
        self.df_view = df
        if df.empty:
            self.status.set("No readings for this selection.")
            return

        unit = aq.VARIABLES[var][0]
        st = aq.summary_stats(df[var])
        self.kpi["Readings"].set(st["n"])
        self.kpi["Mean"].set(f"{st['mean']:.1f} {unit}")
        self.kpi["Median"].set(f"{st['median']:.1f} {unit}")
        self.kpi["Max"].set(f"{st['max']:.1f} {unit}")
        self.kpi["Above NAAQS"].set(f"{100 * df['exceeds_naaqs'].mean():.1f}%" if var == "pm25" else "n/a")
        self.kpi["Anomalies"].set(int(df["anomaly"].sum()))
        self.status.set(f"{os.path.basename(self.csv_path)}: {len(self.df_all)} valid rows, "
                        f"{len(self.rejected)} rejected | showing {sel}")

        self.draw_trends(df, var, unit)
        self.draw_hist(df, var, unit)
        self.draw_stations(var, unit)
        cov = aq.coverage_table(self.df_flagged)
        self.draw_coverage(cov)

        summ = aq.station_summary(self.df_flagged, var)
        self._fill(self.tree_summary, list(summ.columns), summ.itertuples(index=False))
        an = df.loc[df["anomaly"], ["station_id", "date", var, "baseline", "mz"]].copy()
        an["date"] = an["date"].dt.strftime("%Y-%m-%d")
        self._fill(self.tree_anom, list(an.columns), an.round(2).itertuples(index=False))
        self._fill(self.tree_rej, ["line", "reason"], self.rejected)
        self.write_analysis(df, var, unit, st, cov)

    # ------------------------------------------------------------ charts
    def draw_trends(self, df, var, unit):
        fig, canvas = self.figs["Trends"]
        fig.clear()
        ax = fig.add_subplot(111)
        for sid, g in df.groupby("station_id"):
            ax.plot(g["date"], g[var], marker=".", ms=3, lw=0.8, label=sid)
        an = df[df["anomaly"]]
        ax.scatter(an["date"], an[var], s=60, facecolors="none", edgecolors="red",
                   linewidths=1.5, zorder=5, label="Anomaly")
        if var == "pm25":
            ax.axhline(aq.NAAQS_PM25_24H, color="darkorange", ls="--", label="NAAQS 60")
            ax.axhline(aq.WHO_PM25_24H, color="green", ls=":", label="WHO 15")
        ax.set_ylabel(f"{var} ({unit})")
        ax.set_title(f"Daily {var} by station")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=7, ncol=3)
        fig.autofmt_xdate()
        fig.tight_layout()
        canvas.draw()

    def draw_hist(self, df, var, unit):
        fig, canvas = self.figs["Histogram"]
        fig.clear()
        ax = fig.add_subplot(111)
        vals = df[var].to_numpy()
        ax.hist(vals, bins=30, color="steelblue", edgecolor="white")
        ax.axvline(np.mean(vals), color="red", label=f"Mean {np.mean(vals):.1f}")
        ax.axvline(np.median(vals), color="black", ls="--", label=f"Median {np.median(vals):.1f}")
        ax.set_xlabel(f"{var} ({unit})")
        ax.set_ylabel("Readings")
        ax.legend()
        fig.tight_layout()
        canvas.draw()

    def draw_stations(self, var, unit):
        fig, canvas = self.figs["Stations"]
        fig.clear()
        ax = fig.add_subplot(111)
        groups = [(s, g[var].to_numpy()) for s, g in self.df_flagged.groupby("station_id")]
        ax.boxplot([g for _, g in groups])
        ax.set_xticks(range(1, len(groups) + 1), [s for s, _ in groups])
        ax.set_ylabel(f"{var} ({unit})")
        ax.set_title("Comparison of stations (all stations)")
        ax.grid(alpha=0.3, axis="y")
        fig.tight_layout()
        canvas.draw()

    def draw_coverage(self, cov):
        fig, canvas = self.figs["Coverage"]
        fig.clear()
        ax = fig.add_subplot(111)
        ax.bar(cov["station_id"], cov["coverage_pct"], color="teal")
        for i, (c, g) in enumerate(zip(cov["coverage_pct"], cov["longest_gap_days"])):
            ax.text(i, c + 1.5, f"{c:.0f}% / gap {g}d", ha="center", fontsize=8)
        ax.set_ylim(0, 115)
        ax.set_ylabel("% of days with a valid reading")
        ax.set_title("Sampling coverage (sparse stations give less reliable averages)")
        fig.tight_layout()
        canvas.draw()

    # ------------------------------------------------------------ text/export
    def write_analysis(self, df, var, unit, st, cov):
        sparse = cov[cov["coverage_pct"] < 50]["station_id"].tolist()
        lines = [
            f"Variable: {var} ({unit})   Readings shown: {st['n']}",
            f"Mean {st['mean']:.1f}, median {st['median']:.1f}, std {st['std']:.1f}, "
            f"95th percentile {st['p95']:.1f}, max {st['max']:.1f}.",
            "",
        ]
        if var == "pm25":
            lines.append(f"{100 * df['exceeds_naaqs'].mean():.1f}% of readings exceed the Indian "
                         f"24-hour NAAQS (60 µg/m³); {100 * (df['pm25'] > aq.WHO_PM25_24H).mean():.1f}% "
                         "exceed the WHO 2021 guideline (15 µg/m³).")
        lines += [
            f"Anomaly rule: residual from a 15-day rolling median per station, flagged when "
            f"|modified z-score| > {self.thr.get()}. Flagged: {int(df['anomaly'].sum())}.",
            "An anomaly is a statistically unusual reading, not automatically an error; "
            "check it against events (festivals, rain, sensor faults) before removing it.",
            "",
            "Sparse sampling: stations with < 50% coverage: " + (", ".join(sparse) or "none") + ".",
            "Averages from sparse stations have wider uncertainty, can miss short pollution "
            "episodes, and station-to-station comparisons are biased if stations report on "
            "different days. Treat their results as indicative only.",
        ]
        self.text.delete("1.0", "end")
        self.text.insert("1.0", "\n".join(lines))

    def save_csv(self):
        if self.df_view is None or self.df_view.empty:
            messagebox.showinfo("Nothing to export", "Load data first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                            filetypes=[("CSV files", "*.csv")])
        if path:
            out = self.df_view.copy()
            out["date"] = out["date"].dt.strftime("%Y-%m-%d")
            out.to_csv(path, index=False)
            messagebox.showinfo("Exported", f"Saved {len(out)} rows to\n{path}")


if __name__ == "__main__":
    Dashboard().mainloop()
