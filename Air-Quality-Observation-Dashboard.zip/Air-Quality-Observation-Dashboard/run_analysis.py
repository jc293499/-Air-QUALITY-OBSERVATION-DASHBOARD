"""
run_analysis.py - Command-line (no GUI) analysis.

Loads the CSV, validates it, flags anomalies, prints the results and saves
all charts and summary tables into outputs/.
Run:  python run_analysis.py [path/to/readings.csv] [--variable pm25|temperature]
"""

import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")  # headless backend, no window needed
import matplotlib.pyplot as plt
import numpy as np

import aq_core as aq

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "outputs")
FIG_DIR = os.path.join(OUT_DIR, "figures")
LABEL = {"pm25": "PM2.5", "temperature": "Temperature"}


def plot_trends(df, variable, path):
    unit = aq.VARIABLES[variable][0]
    fig, ax = plt.subplots(figsize=(10, 5.4))
    for sid, grp in df.groupby("station_id"):
        ax.plot(grp["date"], grp[variable], marker=".", ms=3, lw=0.9,
                label=f"{sid} {grp['station_name'].iloc[0]}")
    net = aq.daily_network_mean(df, variable)
    roll = net.set_index("date")["network_mean"].rolling("7D").mean()
    ax.plot(roll.index, roll.values, color="black", lw=2.2, label="Network 7-day mean")
    an = df[df["anomaly"]]
    ax.scatter(an["date"], an[variable], s=70, facecolors="none",
               edgecolors="red", linewidths=1.6, zorder=5, label="Anomaly (|M| > 3.5)")
    if variable == "pm25":
        ax.axhline(aq.NAAQS_PM25_24H, color="darkorange", ls="--", lw=1.2,
                   label="India NAAQS 24-h (60)")
        ax.axhline(aq.WHO_PM25_24H, color="green", ls=":", lw=1.2,
                   label="WHO 2021 24-h (15)")
    ax.set_title(f"Daily {LABEL[variable]} trend by station")
    ax.set_ylabel(f"{variable} ({unit})")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7, ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.2))
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_histogram(df, variable, path):
    unit = aq.VARIABLES[variable][0]
    vals = df[variable].dropna().to_numpy()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    ax1.hist(vals, bins=30, color="steelblue", edgecolor="white")
    ax1.axvline(np.mean(vals), color="red", lw=1.5, label=f"Mean {np.mean(vals):.1f}")
    ax1.axvline(np.median(vals), color="black", ls="--", lw=1.5,
                label=f"Median {np.median(vals):.1f}")
    if variable == "pm25":
        ax1.axvline(aq.NAAQS_PM25_24H, color="darkorange", ls=":", lw=1.5, label="NAAQS 60")
    ax1.set_title(f"Distribution of {LABEL[variable]}")
    ax1.set_xlabel(f"{variable} ({unit})")
    ax1.set_ylabel("Number of readings")
    ax1.legend(fontsize=8)
    if variable == "pm25":
        order = [lab for _, lab in aq.PM25_CATEGORIES]
        counts = df["category"].value_counts().reindex(order, fill_value=0)
        colors = ["#2e7d32", "#9ccc65", "#fdd835", "#fb8c00", "#e53935", "#6a1b9a"]
        ax2.bar(counts.index, counts.values, color=colors)
        ax2.set_title("Readings per Indian AQI category")
        ax2.tick_params(axis="x", rotation=30)
    else:
        ax2.hist(df["mz"].dropna(), bins=30, color="gray")
        ax2.set_title("Modified z-scores")
    ax2.set_ylabel("Count")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_station_box(df, variable, path):
    unit = aq.VARIABLES[variable][0]
    groups = [(sid, g[variable].dropna().to_numpy()) for sid, g in df.groupby("station_id")]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.boxplot([g for _, g in groups], showfliers=True)
    ax.set_xticks(range(1, len(groups) + 1), [s for s, _ in groups])
    if variable == "pm25":
        ax.axhline(aq.NAAQS_PM25_24H, color="darkorange", ls="--", lw=1.2, label="NAAQS 60")
        ax.legend(fontsize=8)
    ax.set_title(f"{LABEL[variable]} by station")
    ax.set_ylabel(f"{variable} ({unit})")
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_coverage(cov, sparse, path):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    ax1.bar(cov["station_id"], cov["coverage_pct"], color="teal")
    for x, (c, g) in enumerate(zip(cov["coverage_pct"], cov["longest_gap_days"])):
        ax1.text(x, c + 1.5, f"{c:.0f}%\ngap {g}d", ha="center", fontsize=7)
    ax1.set_ylim(0, 115)
    ax1.set_title("Sampling coverage per station")
    ax1.set_ylabel("% of days with a valid reading")
    pct = [f"{int(f * 100)}%" for f in sparse["fraction"]]
    ax2.errorbar(pct, sparse["mean_of_means"],
                 yerr=[sparse["mean_of_means"] - sparse["p05"],
                       sparse["p95"] - sparse["mean_of_means"]],
                 fmt="o", capsize=6, color="purple")
    ax2.set_title("Mean estimate vs. fraction of days sampled")
    ax2.set_xlabel("Fraction of days kept (500 random trials)")
    ax2.set_ylabel("Estimated mean, 5th-95th pct")
    ax2.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def analyse(csv_path, variable="pm25", threshold=aq.DEFAULT_MZ_THRESHOLD, save=True):
    stations = aq.load_station_metadata(os.path.join(HERE, "data", "station_metadata.json"))
    readings, rejected = aq.load_csv(csv_path, stations)
    df = aq.readings_to_dataframe(readings, stations)
    df = df.dropna(subset=[variable])
    df = aq.flag_anomalies(df, variable, threshold)

    stats = aq.summary_stats(df[variable])
    summary = aq.station_summary(df, variable)
    cov = aq.coverage_table(df)
    densest = cov.sort_values("coverage_pct").iloc[-1]["station_id"]
    sparse = aq.sparse_sampling_experiment(df.loc[df.station_id == densest, variable])
    iqr_count = int(sum(aq.iqr_flags(g[variable]).sum() for _, g in df.groupby("station_id")))

    results = {
        "variable": variable,
        "input_rows": len(readings) + len(rejected),
        "valid": len(readings),
        "rejected": rejected,
        "stats": {k: (round(v, 2) if isinstance(v, float) else v) for k, v in stats.items()},
        "anomalies": int(df["anomaly"].sum()),
        "iqr_flags": iqr_count,
        "sparse_station": densest,
    }
    if variable == "pm25":
        results["days_above_naaqs"] = int(df["exceeds_naaqs"].sum())
        results["pct_above_naaqs"] = round(100 * df["exceeds_naaqs"].mean(), 1)
        results["pct_above_who"] = round(100 * (df["pm25"] > aq.WHO_PM25_24H).mean(), 1)

    if save:
        os.makedirs(FIG_DIR, exist_ok=True)
        plot_trends(df, variable, os.path.join(FIG_DIR, f"fig1_{variable}_trends.png"))
        plot_histogram(df, variable, os.path.join(FIG_DIR, f"fig2_{variable}_histogram.png"))
        plot_station_box(df, variable, os.path.join(FIG_DIR, f"fig3_{variable}_by_station.png"))
        plot_coverage(cov, sparse, os.path.join(FIG_DIR, f"fig4_{variable}_sampling_coverage.png"))
        summary.to_csv(os.path.join(OUT_DIR, f"station_summary_{variable}.csv"), index=False)
        cov.to_csv(os.path.join(OUT_DIR, "sampling_coverage.csv"), index=False)
        sparse.to_csv(os.path.join(OUT_DIR, "sparse_sampling_experiment.csv"), index=False)
        cols = ["station_id", "station_name", "date", variable, "mz"]
        df.loc[df["anomaly"], cols].round({"mz": 2}).to_csv(
            os.path.join(OUT_DIR, f"anomalies_{variable}.csv"), index=False)
        aq.monthly_summary(df, variable).to_csv(
            os.path.join(OUT_DIR, f"monthly_means_{variable}.csv"))
        with open(os.path.join(OUT_DIR, f"results_{variable}.json"), "w") as fh:
            json.dump(results, fh, indent=2, default=str)
    return df, results, summary, cov, sparse


def main():
    p = argparse.ArgumentParser(description="Air-quality observation analysis")
    p.add_argument("csv", nargs="?", default=os.path.join(HERE, "data", "air_quality_readings.csv"))
    p.add_argument("--variable", choices=list(aq.VARIABLES), default="pm25")
    p.add_argument("--threshold", type=float, default=aq.DEFAULT_MZ_THRESHOLD)
    a = p.parse_args()
    df, res, summary, cov, sparse = analyse(a.csv, a.variable, a.threshold)

    print(f"Rows read: {res['input_rows']}  valid: {res['valid']}  rejected: {len(res['rejected'])}")
    for line, why in res["rejected"]:
        print(f"  line {line}: {why}")
    print("Overall statistics:", res["stats"])
    print(f"Anomalies (modified z, |M|>{a.threshold}): {res['anomalies']}  "
          f"| IQR rule would flag: {res['iqr_flags']}")
    if a.variable == "pm25":
        print(f"Readings above NAAQS 60: {res['days_above_naaqs']} ({res['pct_above_naaqs']}%)")
    print("\nStation summary:\n", summary.to_string(index=False))
    print("\nSampling coverage:\n", cov.to_string(index=False))
    print(f"\nSparse-sampling experiment ({res['sparse_station']}):\n", sparse.to_string(index=False))
    print("\nAnomalies:\n", df.loc[df.anomaly, ["station_id", "date", a.variable, "mz"]]
          .round({"mz": 2}).to_string(index=False))
    print(f"\nCharts and tables saved in {OUT_DIR}")


if __name__ == "__main__":
    main()
